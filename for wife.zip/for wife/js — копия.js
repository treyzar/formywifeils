'use strict'
// function printText() {                   //Определение функции
//     document.write("Hello World!");        //Тело функции - вывод текста в документ
//   };
// printText('Hello world!')
//




// функция суммы в массиве
// function sumArray(arr){
//     let sum = 0;
//     for (let i = 0; i < arr.length; i++){
//         sum += arr[i]
//     }
//     return sum  
// }
// console.log(sumArray([1,2,3,4,5]))

// function hello(name) {
//     alert(`Привет ${name}`)
// }
// hello('Гей')

// const hello = function(name){
//     alert(`Привет ${name}`)
// }
// hello('ПРиывет')

// const makeShawerma = function(meat){
//     alert(`Ваша шаурма из ${meat} готова`)
// }
// makeShawerma('Мясо')

// const func = (number) => number / 2
// console.log(func(4))

// const sumArray = (arr) => {
//     let sum = 0
//     for (let i = 0; i < arr.length; i++){
//         sum += arr[i]
//     }
//     return sum
// }
// console.log(sumArray[1,2,34,45,5,6,7])

// function fac(n) {
//     if (n < 2) {
//       return 1
//     } else {
//       return n * fac(n - 1)
//     }
//   }
  
//   console.log(BigInt(fac(700)))

// let phrase = prompt('1 or 2')

// if (phrase === '1') {
//   alert('Ты гей')
// } else {
//   alert('ты пидор')
// }
// let message;
// message = 'Hello world!'
// alert(message)


// let name = 'Джон'
// let admin = name
// alert(admin)

// let question = 'Ты гей?'
// let test = confirm(question)
// if (test == 'Да'){
//     alert('Ты гей')
// }

// let test = prompt('Введите свое имя')
// let boom = alert(test)

// function checkAge(age){
//     if (age >= 18){
//         return true
//     }
//     else {
//         return false
//     }
// }
// let age = prompt('Сколько вам лет',17)

// function showPrimes(n){
//     nextPrime: for (let i = 2; i < n;i++){
//         for (let j = 2; j < i; j++){
//             if (i % j == 0) continue nextPrime
//         }
//         alert (i)
//     }
// }
// let n = prompt()
// showPrimes(n)
// function showPrimes(n) {

//     for (let i = 2; i < n; i++) {
//       if (!isPrime(i)) continue;
  
//       alert(i);  // простое
//     }
//   }
  
//   function isPrime(n) {
//     for (let i = 2; i < n; i++) {
//       if ( n % i == 0) return false;
//     }
//     return true;
//   }

let ask = function(question,yes,no){
    if (confirm(question)) yes()
    else no()
}
function showOk(){
    alert("Другого варианта и не ожидалось")
}
function showCancel(){
    alert("Перезагружай страницу и отвечай по другому")
}
ask('Вы согласны стать моей женой?',showOk,showCancel)